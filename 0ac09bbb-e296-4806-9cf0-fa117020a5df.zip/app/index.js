var x = 0, y = 0, z = 0, a = 0;


function update(value) {
    if (value.isdigit() && a === 0){ 
        x = value
        a = 1 
    }
    else if(value.isdigit() && a === 1){
        if(z === 0) y = x + value 
        else if(z === 1) y = x - value 
        else if(z === 2) y = x * value 
        else if(z === 3) y = x / value
        
        x = y
    }
    else if(value=='+') z = 0
    else if(value=='-') z = 1
    else if(value=='*') z = 2
    else if(value=='/') z = 3
}

function result() {
    //Type the code here.
}

function form_reset() {
    //Type the code here.
}
